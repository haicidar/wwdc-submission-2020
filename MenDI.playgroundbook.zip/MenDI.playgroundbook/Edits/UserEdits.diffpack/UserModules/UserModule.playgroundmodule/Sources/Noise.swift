import SpriteKit
import AVFoundation

var players: [URL: AVAudioPlayer] = [:]
var duplicatePlayers: [AVAudioPlayer] = []

struct Noise {
    let text: String
    let audioName: String
}

struct Item {
    let x: CGFloat
    let y: CGFloat
    let color: UIColor
    
    init (_ x: CGFloat,_ y: CGFloat,_ color: UIColor){
        self.x = x
        self.y = y
        self.color = color
    }
}

public func playEffect(_ name:String,_ view:AVAudioPlayerDelegate,_ vol:Float? = nil,_ delay:Double? = nil) {
    guard let bundle = Bundle.main.path(forResource: name, ofType: "m4a") else { return }
    let soundFileNameURL = URL(fileURLWithPath: bundle)
    
    if let player = players[soundFileNameURL] { //player for sound has been found
        if !player.isPlaying { //player is not in use, so use that one
            player.volume = vol ?? 0.5
            player.prepareToPlay()
            player.play(atTime: player.deviceCurrentTime + (delay ?? 0))
        } else { // player is in use, create a new, duplicate, player and use that instead
            do {
                let duplicatePlayer = try AVAudioPlayer(contentsOf: soundFileNameURL)
                
                duplicatePlayer.delegate = view
                //assign delegate for duplicatePlayer so delegate can remove the duplicate once it's stopped playing
                
                duplicatePlayers.append(duplicatePlayer)
                //add duplicate to array so it doesn't get removed from memory before finishing
                duplicatePlayer.volume = vol ?? 0.5
                duplicatePlayer.prepareToPlay()
                duplicatePlayer.play()
            } catch let error {
                print(error.localizedDescription)
            }
        }
    } else { //player has not been found, create a new player with the URL if possible
        do {
            let player = try AVAudioPlayer(contentsOf: soundFileNameURL)
            players[soundFileNameURL] = player
            player.volume = vol ?? 0.5
            player.prepareToPlay()
            player.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
}
