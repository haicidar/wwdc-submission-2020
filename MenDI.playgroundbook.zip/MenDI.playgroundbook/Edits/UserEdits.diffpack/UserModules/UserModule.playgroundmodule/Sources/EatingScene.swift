import SpriteKit
import AVFoundation

struct Food {
    let name: String
    let x: CGFloat
    let y: CGFloat
    let w: CGFloat
    let h: CGFloat
    
    init(_ name:String,_ x:CGFloat,_ y:CGFloat,_ w:CGFloat,_ h:CGFloat){
        self.name = name
        self.x = x
        self.y = y
        self.w = w
        self.h = h
    }
}

public class EatingScene : SKScene, AVAudioPlayerDelegate {
    var foodList: [Food] = []
    var foodNode: [SKSpriteNode] = []
    public override func didMove(to view: SKView) {
        //background
        let bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "table.png")))
        bg.zPosition = -10
        bg.size = CGSize(width: 600, height: 750)
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(bg)
        
        //foodList
        foodList.append(Food("food1", 172, 57, 169, 154))
        foodList.append(Food("food2", 228, 299, 137, 176))
        foodList.append(Food("food3",391, 369, 137, 137))
        foodList.append(Food("food4", 129, 369, 86, 113))
        foodList.append(Food("food5", 82, 199, 150, 150))
        foodList.append(Food("food6", 357, 156, 164, 165))
        foodList.append(Food("food7", 257, 210, 65, 80))
        foodList.append(Food("food8", 224, 512, 141, 140))
        foodList.append(Food("food9", 375, 518, 128, 113))
        foodList.append(Food("food10", 104, 512, 94, 93))
        
        for food in foodList{
            createFood(food)
        }
        
        //set the diamond
        foodNode.randomElement()?.name = "setDiamond"
    }
    
    func createFood(_ food:Food){
        let node = SKSpriteNode(texture: SKTexture(image:UIImage(named: food.name)!), color: .clear, size: CGSize(width: food.w + 25
            , height: food.h + 25))
        node.position = CGPoint(x: frame.minX + food.x + node.size.width/2, y: frame.maxY - food.y - node.size.height/2)
        node.name = "food"
        
        foodNode.append(node)
        addChild(foodNode.last!)
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let node = self.atPoint(t.location(in: self))
            if (node.name == "food"){
                playEffect("eat", self)
                
                var act = [SKAction]()
                let fadeOut = SKAction.fadeOut(withDuration: 1)
                let remove = SKAction.removeFromParent()
                act.append(fadeOut)
                act.append(remove)
                let actSeq = SKAction.sequence(act)
                node.run(actSeq)
                
            }else if (node.name == "setDiamond") {
                changeToDiamond(node as! SKSpriteNode, self)
            }else if (node.name == "diamond"){
                correct(self.frame, self, contentCorrect[1])
            }else if (node.name == "home"){
                backToHome(self.view!)
            }
        }
    }
}
