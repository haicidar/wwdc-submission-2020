import SpriteKit

public class MainScene: SKScene {
    public override func didMove(to view: SKView) {
        var content : [String] = []
        //psychotic content
        content.append("Didn’t You Hear That?\n\n\nIn this game you have to collect the diamond by clicking on it.\n\nYou should reveal the diamond by clicking on objects that you think there is a diamond on them.\n\nClue :\nListen to the sound.\n\n\n\nClick this card to play")
        //eating content
        content.append("Bon appetite!\n\n\nIn this game you have to collect the diamond by clicking on it.\n\nYou should reveal the diamond by eat the foods (by clicking on it) that you think there is a diamond on them.\n\nClue :\nJust eat.\n\n\n\nClick this card to play")
        
        // background
        let bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "mainBg.jpg")))
        bg.size =  CGSize(width: 600, height: 750)
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        bg.zPosition = -10
        addChild(bg)
        
        // title label
        let title = SKLabelNode(text: "Collect Your Diamonds!")
        title.verticalAlignmentMode = SKLabelVerticalAlignmentMode.top
        title.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        title.numberOfLines = 0
        title.preferredMaxLayoutWidth = 500
        title.fontSize = 40
        title.position = CGPoint(x: frame.minX + 20, y: frame.maxY - 20)
        title.fontColor = .white
        addChild(title)
        
        createCard("psychotic", -250, frame.midX - 20, content[0])
        createCard("eating", 0, frame.midX + 20, content[1])
    }
    
    func createCard(_ name: String,_ xRect: Double,_ xPoint: CGFloat,_ content:String) {
        let shape = SKShapeNode()
        shape.name = name
        shape.path = UIBezierPath(roundedRect: CGRect(x: xRect, y: 0, width: 250, height: 400), cornerRadius: 25).cgPath
        shape.position = CGPoint(x: xPoint, y: frame.minY + 20)
        shape.fillColor = UIColor.black
        shape.alpha = 0.8
        shape.strokeColor = UIColor.white
        addChild(shape)
        
        let attrString = NSMutableAttributedString(string: content)
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let range = NSRange(location: 0, length: content.count)
        
        let text = SKLabelNode()
        
        attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: range)
        attrString.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont(name: text.fontName!, size:  17.0)], range: range)
        
        text.attributedText = attrString
        text.name = name
        text.verticalAlignmentMode = SKLabelVerticalAlignmentMode.center
        text.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.center
        text.numberOfLines = 0
        text.preferredMaxLayoutWidth = 220
        text.position = CGPoint(x: shape.position.x + CGFloat(xRect) + 125, y: shape.position.y + 200)
        addChild(text)
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let node = self.atPoint(t.location(in: self))
            if (node.name == "psychotic"){
                let scene = PsychoticScene()
                scene.size = CGSize(width: 600, height: 750)
                scene.scaleMode = .aspectFit
                let transition = SKTransition.reveal(with: .right, duration: 1)
                self.view?.presentScene(scene, transition: transition)
            }else if (node.name == "eating"){
                let scene = EatingScene()
                scene.size = CGSize(width: 600, height: 750)
                scene.scaleMode = .aspectFit
                let transition = SKTransition.reveal(with: .right, duration: 1)
                self.view?.presentScene(scene, transition: transition)
            }
        }
    }
}

