
/*
 
 Credit
 
 Main Background : Photo by Khánh Trung Lê on Unsplash
 
 Psychotic Background : Photo by Minh Pham on Unsplash
 
 Eating Background : Photo by Ria Puskas on Unsplash, Photo by Wesley Tingey on Unsplash
 
 Foods :
 Photo by Thought Catalog on Unsplash,
 Photo by Rachel Park on Unsplash,
 Photo by Brooke Lark on Unsplash,
 Photo by Cristiano Pinto on Unsplash,
 Photo by The Fry Family Food Co. on Unsplash,
 Photo by Karl Janisse on Unsplash
 
 Clock : Photo by Samantha Gades on Unsplash
 
 Clock Sound :
 free sound effects from https://www.fesliyanstudios.com
 
 Mental disorder info by https://medlineplus.gov
 
 Others assets are created by me
 */
