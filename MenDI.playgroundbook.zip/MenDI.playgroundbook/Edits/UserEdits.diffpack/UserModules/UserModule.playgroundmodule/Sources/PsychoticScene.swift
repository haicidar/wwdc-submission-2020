import SpriteKit
import AVFoundation

public class PsychoticScene : SKScene, AVAudioPlayerDelegate {
    var clockSound: AVAudioPlayer!
    var noiseList : [Noise] = [Noise(text: "The diamond's here", audioName: "3"), Noise(text: "NO, It's here", audioName: "2"), Noise(text: "Click ME!", audioName: "1"), Noise(text: "It's here", audioName: "4")]
    var itemList : [Item] = []
    var noiseLabel : [SKLabelNode] = []
    var timer = Timer()
    var countTime = 0
    var noiseVol:Float = 0.4
    
    public override func didMove(to view: SKView) {
        //timer
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(showNoise), userInfo: nil, repeats: true)
        // background
        let bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "psychoticBg.jpg")))
        bg.name = "object"
        bg.zPosition = -10
        bg.size = CGSize(width: 600, height: 750)
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(bg)
        
        // itemlist
        itemList.append(Item(250, 330, .white)) //guitar
        itemList.append(Item(10, 190, .white))//tv
        itemList.append(Item(410, 430, .brown))//vase
        itemList.append(Item(90, 580, .white))//pillow
        itemList.append(Item(290, 670, .white))//sandals
        itemList.append(Item(10, 340, .brown))//drawer
        
        for item in itemList{
            createNoise(item.x, item.y, item.color)
        }
        
        // clockSound
        do{
            let clockSoundPath = Bundle.main.path(forResource: "clock", ofType: ".mp3")
            try clockSound = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: clockSoundPath!) as URL)
        } catch {
            // error
        }
        clockSound.numberOfLoops = -1
        clockSound.volume = 0.1
        clockSound.prepareToPlay()
        clockSound.play()
        clockSound.setVolume(0.5, fadeDuration: 30)
        
        // clock
        let clock = SKSpriteNode(texture: SKTexture(image:#imageLiteral(resourceName: "clock.png")), color: .clear, size: CGSize(width: 80, height: 80.5))
        clock.name = "clock"
        clock.position = CGPoint(x: frame.maxX/4, y: 720)
        addChild(clock)
    }
    
    func createNoise(_ x:CGFloat,_ y:CGFloat,_ color:UIColor){
        let text = SKLabelNode(fontNamed: "AvenirNext-Bold")
        text.name = "object"
        text.verticalAlignmentMode = SKLabelVerticalAlignmentMode.top
        text.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.left
        text.preferredMaxLayoutWidth = 135
        text.fontSize = 18
        text.position = CGPoint(x: frame.minX + x, y: frame.maxY - y) //position
        text.zPosition = 1
        text.fontColor = color //color
        text.alpha = 0
        noiseLabel.append(text)
        addChild(noiseLabel.last!)
    }
    
    @objc func showNoise() {
        if countTime % 3 == 0 && countTime < 33{
            let rand = Int.random(in: 0 ... 2)
            noiseLabel.shuffle()
            for n in 0...rand{
                let noiseRand = noiseList.randomElement()
                noiseLabel[n].text = noiseRand?.text
                var act = [SKAction]()
                let fadeIn = SKAction.fadeIn(withDuration: 0.4)
                let wait = SKAction.wait(forDuration: 2.2)
                let fadeOut = SKAction.fadeOut(withDuration: 0.4)
                act.append(fadeIn)
                act.append(wait)
                act.append(fadeOut)
                
                let actSeq = SKAction.sequence(act)
                noiseLabel[n].run(actSeq)
                
                let delay = Double.random(in: 0 ... 0.4)
                
                playEffect(noiseRand!.audioName, self, noiseVol, delay)
            }
        }
        countTime += 1
        if countTime % 4 == 0 {
            noiseVol = noiseVol - 0.05
        }
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            let node = self.atPoint(t.location(in: self))
            if (node.name == "clock"){
                changeToDiamond(node as! SKSpriteNode, self)
                timer.invalidate()
                clockSound.stop()
            }else if (node.name == "diamond") {
                correct(self.frame, self, contentCorrect[0])
            }else if (node.name == "home"){
                backToHome(self.view!)
            }else if (node.name == "object"){
                playEffect("wrong", self)
            }
        }
    }
    
}
