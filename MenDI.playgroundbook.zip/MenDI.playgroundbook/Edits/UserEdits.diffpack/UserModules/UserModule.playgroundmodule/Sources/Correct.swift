import SpriteKit
import AVFoundation

var contentCorrect:[String] = ["COOL, you’ve found ‘the sound’ \n\nWhen you hear something, and you don't know whether it is real or not, adjust your breath, calm yourself and hope that the noise disappears \nor you can tell someone about what you heard. \n_______________________________________________________ \n\nPsychotic Disorders are severe mental disorders that cause abnormal thinking and perceptions. People with psychoses lose touch with reality. Two of the main symptoms are delusions and hallucinations. \n\nDon’t be panick if you have the symptoms, you can tell someone about what happened to you. \nIt’s normal when we have disorder, we are human anyway. \n\nActually I think you can write your hallucinations and make a fiction book out of it. \nSeems like it can be a best seller :)", "Wow you’ve eaten a lot \n\nI know you’re forced to eat them to find the diamond, hope that you enjoy the foods and not to hurt your stomach, if it happens in your real life, I think you can share the foods to others instead. \n_______________________________________________________ \n\nEating Disorders are serious mental health disorders. They involve severe problems with your thoughts about food and your eating behaviors. You may eat much less or much more than you need. \n\nIt's normal to have an increased or decreased appetite when something happened to us, as long as it doesn't last long and affect our health. When that happens you may tell someone about what happened to you. \nIt’s normal when we have disorder, we are human anyway. \n\nOr maybe you can share your food and eat together instead of alone and then make friends with them :) \nThere is no one who doesn't like to eat right?"]

public func changeToDiamond(_ node: SKSpriteNode,_ self:AVAudioPlayerDelegate) {
    playEffect("tringg", self)
    let diamond = SKTexture(image: #imageLiteral(resourceName: "diamond.png"))
    node.name = "diamond"
    node.position = CGPoint(x: node.position.x, y: node.position.y - 20)
    node.size = CGSize(width: 60, height: 50.5)
    let change = SKAction.setTexture(diamond)
    node.run(change)
}


public func correct(_ frame: CGRect,_ scene: SKScene,_ content:String) {
    let bg = SKSpriteNode(color: .black, size: CGSize(width: 600, height: 750))
    bg.zPosition = 3
    bg.alpha = 0.8
    bg.position = CGPoint(x: frame.midX, y: frame.midY)
    scene.addChild(bg)
    
    let home = SKShapeNode(rectOf: CGSize(width: 150, height: 50), cornerRadius: 5)
    home.name = "home"
    home.position = CGPoint(x: frame.midX, y: frame.minY + 75)
    home.fillColor = UIColor.white
    home.strokeColor = UIColor.white
    home.zPosition = 4
    home.alpha = 0.5
    scene.addChild(home)
    
    let homeText = SKLabelNode(text: "Back to Main")
    homeText.name = "home"
    homeText.position = CGPoint(x: frame.midX, y: frame.minY + 75)
    homeText.fontColor = .black
    homeText.fontSize = 17
    homeText.zPosition = 5
    homeText.verticalAlignmentMode = SKLabelVerticalAlignmentMode.center
    homeText.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.center
    scene.addChild(homeText)
    
    let contentText = SKLabelNode(text: content)
    let attrString = NSMutableAttributedString(string: content)
    let paragraphStyle = NSMutableParagraphStyle()
    paragraphStyle.alignment = .center
    let range = NSRange(location: 0, length: content.count)
    
    attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: range)
    attrString.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white, NSAttributedString.Key.font : UIFont(name: contentText.fontName!, size:  18.0)], range: range)
    
    contentText.attributedText = attrString
    
    contentText.verticalAlignmentMode = SKLabelVerticalAlignmentMode.center
    contentText.horizontalAlignmentMode = SKLabelHorizontalAlignmentMode.center
    contentText.position = CGPoint(x: frame.midX, y: frame.midY + 100)
    contentText.zPosition = 4
    contentText.numberOfLines = 0
    contentText.preferredMaxLayoutWidth = 500
    
    scene.addChild(contentText)
}

public func backToHome(_ view:SKView) {
    let scene = MainScene()
    scene.size = CGSize(width: 600, height: 750)
    scene.scaleMode = .aspectFit
    let transition = SKTransition.reveal(with: .right, duration: 1)
    view.presentScene(scene, transition: transition)
    
}

